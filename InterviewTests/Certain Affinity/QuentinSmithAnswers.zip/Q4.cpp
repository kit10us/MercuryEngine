#include <iostream>
#include <conio.h>
#include <string>
#include <assert.h>

long MultiplyBySeven(long input)
{
	long times7 = 0;
	for ( long i = 0; i < input; ++i )
	{
		times7 += 7;
	}
	return times7;
}

void Q4()
{
   long threeTimesSeven = MultiplyBySeven(3);
   
   assert(threeTimesSeven==21);
}

int main( int argc, char ** argv )
{
	Q4();
	printf( "Press any key to end program.\n" );
	while( !_getch() );
	return 0;
}